#include "UI_StopCauseListDialog.h"

UI_StopCauseListDialog::UI_StopCauseListDialog()
{
	
}


UI_StopCauseListDialog::~UI_StopCauseListDialog()
{
}

void UI_StopCauseListDialog::InitUI()
{

}
