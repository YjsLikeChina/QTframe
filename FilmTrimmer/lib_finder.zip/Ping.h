#pragma once
class CPing
{
public:
	CPing(void);
	~CPing(void);
	bool Ping(char* ip);
};

